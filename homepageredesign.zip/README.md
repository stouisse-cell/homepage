# Rahim International — GitHub Pages homepage

A complete **static, responsive French / English / Arabic** homepage inspired by the approved cool-toned (marine, slate and ivory) editorial concept. Built with semantic HTML, CSS and vanilla JavaScript — no build tools or dependencies.

## Quick preview

Open `index.html` in your browser, or use a local web server:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000/`.

## Publish with GitHub Pages

1. Create a **public GitHub repository** (for example, `rahim-international-site`).
2. Upload the contents of this folder **to the repository root**, keeping `index.html`, `styles.css`, `script.js`, and the `assets` folder together.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**. Select `main` and `/(root)`, then Save.
5. Your GitHub Pages URL will appear in the Pages settings. To use `rahiminternational.com`, follow GitHub's custom-domain steps and your domain provider's DNS instructions. Do not change DNS before checking your existing website/email setup.

The site uses relative file paths, so it can also be published under a GitHub Pages project URL such as `username.github.io/repository/`.

## Files

- `index.html` — navigation, hero, services, region, showcase, process, founder, guides, contact CTA, footer.
- `styles.css` — responsive layouts, fonts, color palette and botanical overlays.
- `script.js` — functional mobile navigation and FR/EN/AR language switching.
- `assets/olive-shadow.svg` — transparent botanical background (not an image screenshot); adjust its opacity in CSS.
- `assets/bridge-mark.svg` — **approximate bridge-inspired mark**, not the verified official Rahim International logo. Replace with your official vector logo when available.
- `assets/*.webp` — visuals **cropped from the previously generated website concept**, supplied solely for prototyping the look. **These are illustrative mockup images, not verified photographs of actual properties or Kénitra landmarks.** Replace with authentic, properly licensed photography before going live.
- `assets/founder-placeholder.webp` — **illustrative placeholder portrait**. Replace with Ali Rahim's real approved portrait before publication.

## Palette

Change these CSS custom properties near the top of `styles.css` to test colors:

```css
--ivory: #f8f8f6;
--paper: #f3f4f2;
--stone: #e6e9e8;
--slate: #8299ac;
--navy: #173852;
--navy-deep: #0d293f;
--ink: #172c3c;
--brass: #ab8a53;
```

## Swap images

To update an image without changing HTML, replace the matching file inside `assets/` with another image of the same filename and extension. Or change the `src` in `index.html` / `background` URL in `styles.css`. Choose optimized WebP images when possible.

## Leaf graphic

The olive leaf background is in `assets/olive-shadow.svg`, used as a CSS background on `.botanical-right` and `.botanical-left`. To reduce its visibility, change `opacity: .19;` in `styles.css`. You can move it by adjusting the `right`, `left`, `bottom`, and `transform` rules.

## Important before publishing

- Check the phone number (`+212 6 42 77 32 49`) and email (`contact@rahiminternational.com`) and confirm these are your desired public contacts.
- Replace the approximate logo, founder placeholder, illustrative architectural imagery and any unverified copy/claims before publishing.
- All contact and project/guide inquiries link to email or WhatsApp (there is **no backend, database or live property inventory**). Connect the cards to your real pages when they are available.
- Google Fonts are loaded via Google's font CDN; the site falls back to system fonts if they are blocked.
- The HTML includes `FR`, `EN`, `AR` language controls for the visible text. Proper Arabic typeface and editorial RTL polish can be further refined.
