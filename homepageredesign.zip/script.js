'use strict';
// Fully static: no analytics, trackers, APIs, or frameworks.
const languageCopy = {
  en: {
    tagline: 'Real estate advisory & strategy',
    navHome: 'Home', navBuyers: 'Buyers', navDevelopers: 'Developers', navGuides: 'Guides', navAbout: 'About', navContact: 'Contact',
    consult: 'Plan my consultation <span aria-hidden="true">→</span>',
    ourServices: 'Our services <span aria-hidden="true">↗</span>',
    heroEyebrow: 'Independent real estate advisory<br>Morocco',
    heroLine1: 'Your real estate<br>project in Morocco.',
    heroLine2: 'Our presence<br>on the ground.',
    heroDesc: 'From the first conversation to the final signature, we guide you with a clear process, independent advice and in-depth knowledge of the local market.',
    servicesKicker: 'Our services',
    servicesTitle: 'Tailored guidance<br>at every step.',
    servicesDesc: 'Whether you are a private buyer, a Moroccan living abroad, an international investor or a developer, we offer independent, transparent guidance tailored to your objectives.',
    viewServices: 'Explore our services <span aria-hidden="true">→</span>',
    service1Title: 'Individuals &amp; MRE', service1Text: 'Buy confidently in Morocco, whether you are here or abroad.',
    service2Title: 'International investors', service2Text: 'Carefully selected opportunities and rigorous analysis.',
    service3Title: 'Developers', service3Text: 'A strategic partner to help position and market your project.',
    service4Title: 'Research &amp; advice', service4Text: 'Independent insight and recommendations you can act on.',
    regionKicker: 'Kénitra and the region', regionTitle: 'A region<br>on the move.',
    regionDesc: 'Between Rabat and Salé, Kénitra offers distinctive opportunities, modern infrastructure, sustained economic growth and an evolving quality of life.',
    discoverRegion: 'Discover the region <span aria-hidden="true">→</span>',
    benefit1: 'Modern<br>infrastructure', benefit2: 'Strategic<br>location', benefit3: 'Investment<br>opportunities', benefit4: 'Quality of life',
    projectsKicker: 'Selected opportunities', projectsTitle: 'Real opportunities.',
    viewProjects: 'Ask about opportunities <span aria-hidden="true">→</span>',
    project1: 'Residential', project1Desc: 'Apartments · Villas · Quality homes',
    project2: 'Investment', project2Desc: 'Returns · Strategic locations',
    project3: 'New developments', project3Desc: 'Support from reservation to handover',
    project4: 'Tailored opportunities', project4Desc: 'A personalized selection',
    imageryNote: 'Illustrative images · Contact us for currently available properties.',
    processKicker: 'A clear process', processTitle: 'How does it work?',
    step1: 'Listen &amp; analyze', step1Desc: 'We discuss your goals and budget.',
    step2: 'Search &amp; visit', step2Desc: 'We shortlist options and arrange viewings.',
    step3: 'Negotiate &amp; support', step3Desc: 'We guide you through signing and beyond.',
    processAside: 'A personal<br>and strategic<br>approach.',
    founderKicker: 'Your local contact', cofounder: 'Co-founder',
    founderDesc: 'More than five years of real estate experience in Kénitra. Ali visits, verifies and negotiates on your behalf, combining local market knowledge with a trusted network.',
    ourStory: 'Our story <span aria-hidden="true">→</span>',
    quote: 'Our mission is simple: to make your real estate journey calm, transparent and effective, whether you are in Morocco or abroad.',
    guidesKicker: 'Guides &amp; resources', guidesTitle: 'The knowledge to move<br>forward with confidence.',
    guidesDesc: 'Our practical guides and market insights help you understand Moroccan real estate and make better-informed decisions.',
    allGuides: 'Request the guides <span aria-hidden="true">→</span>',
    guide1: 'Buying in Morocco', guide1Desc: 'Steps, costs and practical advice',
    guide2: 'MRE guide', guide2Desc: 'Investing from overseas',
    guide3: 'Daam Sakane', guide3Desc: 'Eligibility and applications',
    guide4: 'Financing', guide4Desc: 'Banks and lending options',
    ctaTitle: 'Morocco,<br>closer than ever.',
    ctaDesc: 'Trusted support to make your real estate plans in Morocco a reality, with peace of mind.',
    footerIntro: 'A bridge between your plans and Morocco. Independent real estate advisory for Moroccans abroad, international investors and developers. Kénitra · Rabat · Salé · and beyond.',
    footerNav: 'Navigation', footerServices: 'Our services', footerContact: 'Contact us', byAppt: 'By appointment only', rights: 'All rights reserved.'
  },
  ar: {
    tagline: 'استشارات واستراتيجيات عقارية',
    navHome: 'الرئيسية', navBuyers: 'المشترون', navDevelopers: 'المنعشون', navGuides: 'الأدلة', navAbout: 'من نحن', navContact: 'اتصل بنا',
    consult: 'حضّر استشارتك <span aria-hidden="true">←</span>',
    ourServices: 'خدماتنا <span aria-hidden="true">↗</span>',
    heroEyebrow: 'استشارات عقارية مستقلة<br>المغرب',
    heroLine1: 'مشروعك العقاري<br>في المغرب.',
    heroLine2: 'وحضورنا<br>على أرض الواقع.',
    heroDesc: 'من التفكير الأولي إلى توقيع العقد، نرافقك بمنهجية واضحة واستشارة مستقلة ومعرفة معمقة بالسوق المحلي.',
    servicesKicker: 'خدماتنا',
    servicesTitle: 'مرافقة مخصصة<br>في كل مرحلة.',
    servicesDesc: 'سواء كنت مشترياً أو مغربياً مقيماً بالخارج أو مستثمراً دولياً أو منعشاً عقارياً، نقدم لك مرافقة مستقلة وشفافة تلائم أهدافك.',
    viewServices: 'اكتشف خدماتنا <span aria-hidden="true">←</span>',
    service1Title: 'الأفراد ومغاربة العالم', service1Text: 'اشترِ بثقة في المغرب، سواء كنت داخله أو خارجه.',
    service2Title: 'المستثمرون الدوليون', service2Text: 'فرص منتقاة ودراسة دقيقة لكل مشروع.',
    service3Title: 'المنعشون العقاريون', service3Text: 'شريك استراتيجي لدعم وتسويق مشاريعكم.',
    service4Title: 'الدراسات والاستشارات', service4Text: 'تحليلات مستقلة وتوصيات واضحة.',
    regionKicker: 'القنيطرة والمنطقة', regionTitle: 'منطقة<br>في تطور مستمر.',
    regionDesc: 'تقدم القنيطرة، بالقرب من الرباط وسلا، فرصاً متميزة بفضل البنية التحتية الحديثة والنمو الاقتصادي وتحسن جودة الحياة.',
    discoverRegion: 'اكتشف المنطقة <span aria-hidden="true">←</span>',
    benefit1: 'بنية تحتية<br>حديثة', benefit2: 'موقع<br>استراتيجي', benefit3: 'فرص<br>استثمارية', benefit4: 'جودة الحياة',
    projectsKicker: 'فرص مختارة', projectsTitle: 'فرص عقارية حقيقية.',
    viewProjects: 'استفسر عن الفرص <span aria-hidden="true">←</span>',
    project1: 'عقارات سكنية', project1Desc: 'شقق · فيلات · مساكن عالية الجودة',
    project2: 'استثمار', project2Desc: 'عائد استثماري · مواقع مميزة',
    project3: 'مشاريع جديدة', project3Desc: 'مرافقة من الحجز إلى تسليم المفاتيح',
    project4: 'فرص مخصصة', project4Desc: 'اختيارات حسب احتياجاتك',
    imageryNote: 'الصور توضيحية · تواصلوا معنا لمعرفة العقارات المتاحة حالياً.',
    processKicker: 'خطوات واضحة', processTitle: 'كيف نعمل؟',
    step1: 'الاستماع والتحليل', step1Desc: 'نتعرف على أهدافك وميزانيتك.',
    step2: 'البحث والزيارة', step2Desc: 'نختار الخيارات المناسبة وننظم الزيارات.',
    step3: 'التفاوض والمتابعة', step3Desc: 'نرافقك حتى التوقيع وما بعده.',
    processAside: 'مقاربة<br>إنسانية<br>واستراتيجية.',
    founderKicker: 'جهة اتصالكم محلياً', cofounder: 'شريك مؤسس',
    founderDesc: 'أكثر من خمس سنوات من الخبرة العقارية في القنيطرة. يتولى علي الزيارات والتحقق والتفاوض بالنيابة عنكم بمعرفة معمقة بالسوق المحلي وشبكة علاقات موثوقة.',
    ourStory: 'قصتنا <span aria-hidden="true">←</span>',
    quote: 'مهمتنا بسيطة: توفير تجربة عقارية مريحة وشفافة وفعالة، سواء كنتم في المغرب أو خارجه.',
    guidesKicker: 'الأدلة والموارد', guidesTitle: 'معلومات تساعدكم<br>على التقدم بثقة.',
    guidesDesc: 'تساعدكم أدلتنا العملية وتحليلاتنا على فهم السوق العقاري المغربي واتخاذ قرارات مدروسة.',
    allGuides: 'اطلب الأدلة <span aria-hidden="true">←</span>',
    guide1: 'الشراء في المغرب', guide1Desc: 'الخطوات والتكاليف والنصائح',
    guide2: 'دليل مغاربة العالم', guide2Desc: 'الاستثمار من الخارج',
    guide3: 'دعم السكن', guide3Desc: 'الشروط والإجراءات',
    guide4: 'التمويل', guide4Desc: 'البنوك وخيارات القروض',
    ctaTitle: 'المغرب،<br>أقرب من أي وقت مضى.',
    ctaDesc: 'مرافقة موثوقة لتحويل مشروعكم العقاري بالمغرب إلى واقع بكل راحة واطمئنان.',
    footerIntro: 'جسر يربط مشاريعكم بالمغرب. استشارات عقارية مستقلة لمغاربة العالم والمستثمرين الدوليين والمنعشين العقاريين. القنيطرة · الرباط · سلا · وما بعدها.',
    footerNav: 'روابط', footerServices: 'خدماتنا', footerContact: 'اتصل بنا', byAppt: 'اللقاءات بموعد مسبق', rights: 'جميع الحقوق محفوظة.'
  }
};

const translatable = [...document.querySelectorAll('[data-i18n]')];
const originalFrench = new Map(translatable.map(el => [el, el.innerHTML]));
const langButtons = [...document.querySelectorAll('[data-lang]')];
function setLanguage(lang) {
  if (!['fr','en','ar'].includes(lang)) return;
  const translations = languageCopy[lang] || {};
  translatable.forEach(element => {
    const key = element.dataset.i18n;
    element.innerHTML = lang === 'fr' ? originalFrench.get(element) : (translations[key] || originalFrench.get(element));
  });
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  langButtons.forEach(button => {
    const active = button.dataset.lang === lang;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  document.title = lang === 'fr' ? 'Rahim International | Conseil immobilier indépendant au Maroc' :
    lang === 'en' ? 'Rahim International | Independent real estate advisory in Morocco' :
      'رحيم إنترناشيونال | استشارات عقارية مستقلة بالمغرب';
}
langButtons.forEach(button => button.addEventListener('click', () => setLanguage(button.dataset.lang)));

// Small-screen navigation, keyboard accessible.
const menuToggle = document.querySelector('.menu-toggle');
const mainNav = document.querySelector('.main-nav');
function closeMenu() {
  mainNav.classList.remove('is-open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.setAttribute('aria-label', 'Ouvrir le menu');
}
menuToggle.addEventListener('click', () => {
  const open = mainNav.classList.toggle('is-open');
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
});
mainNav.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
window.addEventListener('resize', () => { if (window.innerWidth > 980) closeMenu(); });

document.getElementById('year').textContent = new Date().getFullYear();
